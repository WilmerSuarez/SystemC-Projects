// ============== ROBOT NAVIGATION ============== //
// 
// File : environment.h
// This module emulates the robot's motors, GPS, 
// sensors, and human traffic. 
//
// ============================================== //
#ifndef __ENVIRONMENT_H__
#define __ENVIRONMENT_H__
#include "defs.h"

#define CONTINUE    1
#define START       2
#define STOP        4

class environment : public sc_module {
    public:
        // ----- PORTS ----- //
        sc_in_clk clk;
        sc_in <sc_bv<3> > packet_fromS[ROBOT_NUM];      // Packet from Server
        sc_out <sc_bv<3> > packet_toS[ROBOT_NUM];       // Packet to Server 

        // ----- INTERNAL SIGNALS ----- // 
        sc_signal<float> r1_speed;
        sc_signal<float> r2_speed;
        sc_signal<float> r3_speed;
        sc_signal<float> r4_speed;
        
        // ----- CONSTRUCTOR ----- //
        SC_HAS_PROCESS(environment);
        environment(sc_module_name name, const std::vector<std::vector<uint> > obstaclePath) : 
            sc_module(name),
            _obstaclePath(obstaclePath) {

                SC_THREAD(environment_rx);
                    for(uint i =  0; i < ROBOT_NUM; ++i) {
                        sensitive << packet_fromS[i];
                    }

                SC_CTHREAD(environment_update, clk.pos());

                SC_THREAD(environment_tx);
                    sensitive << _e_tx;
                    
                /* Port Initialization */
                for(uint i =  0; i < ROBOT_NUM; ++i) {
                    packet_toS[i].initialize(0);
                }

                /* Robot Map Initialization */
                for(unsigned r = 0; r < ROBOT_NUM; ++r) {
                    robotMap[r].gridNum = RSDS[r].CG.front();
                    robotMap[r].STATUS = IDLE;
                    for(uint x = 0; x < MAX_GRID_NUM_X; ++x) {
                        for(uint y = 0; y < MAX_GRID_NUM_Y; ++y) {
                            if(map[x][y].gridNum == robotMap[r].gridNum) {
                                robotMap[r]._g_x = x;
                                robotMap[r]._g_y = y;
                                robotMap[r]._r_x = map[x][y].LL.x + 1;
                                robotMap[r]._r_y = map[x][y].LL.y + 1;
                            }
                        }
                    }
                }

                /* Obstacle Map Initialization*/
                for(unsigned o = 0; o < OBSTACLE_NUM; ++o) {
                    obstacleMap[o].G = _obstaclePath[o];
                    obstacleMap[o].n = 0;
                    obstacleMap[o].s = 0;
                    obstacleMap[o].w = 0;
                    obstacleMap[o].e = 0;
                    for(uint x = 0; x < MAX_GRID_NUM_X; ++x) {
                        for(uint y = 0; y < MAX_GRID_NUM_Y; ++y) {
                            if(map[x][y].gridNum == obstacleMap[o].G.front()) {
                                obstacleMap[o]._g_x = x;
                                obstacleMap[o]._g_y = y;
                                obstacleMap[o]._o_x = map[x][y].LL.x + 1;
                                obstacleMap[o]._o_y = map[x][y].LL.y + 1;
                            }
                        }
                    }
                    obstacleMap[o].speed = OBSTACLE_SPEED_MAX;
                }
            }
    private:
        // ----- METHODS ----- //
        void environment_rx(); 
        void update_robot_positions();
        void environment_update();
        void environment_tx();
        void update_robot_pos();
        void update_obstacle_pos();
        void robot_boundary_check();
        void robot_collision_check();

        // ----- INTERNAL VARIABLES ----- //
        /* Obstacle Path */
        const std::vector<std::vector<uint> > _obstaclePath;

        /* 
            Robot position Table
        */
        struct robotMap {
            uint gridNum;           // Robot Grid Number
            float _r_x;             // X position of Robot
            float _r_y;             // Y position of Robot 
            uint _g_x;              // X position of Robot in grid
            uint _g_y;              // Y position of Robot in grid
            std::string STATUS;     // Robot Status
        } robotMap[ROBOT_NUM];

        /* 
            Obstacle position Table
        */
        struct obstacleMap {
            uint _g_x;              // X position of Obstacle in grid
            uint _g_y;              // Y position of Obstacle in grid
            float _o_x;             // X position of Obstacle
            float _o_y;             // Y position of Obstacle
            std::vector<uint> G;    // Obstacle Grid Number
            float speed;            // Obstacle speed (always 5/ms)
            uint n;                 // Obstacle path selection north index 
            uint s;                 // Obstacle path selection south index
            uint w;                 // Obstacle path selection west index
            uint e;                 // Obstacle path selection east index
        } obstacleMap[OBSTACLE_NUM];
        
        sc_event _e_tx;                               // Event triggered when environment is ready to transmit packet  
        sc_bv<3> _packet_toS[ROBOT_NUM] = { 0 };      // Holds the current outgoing packet to the server
        sc_bv<3> _packet_fromS[ROBOT_NUM] = { 0 };    // Holds incoming packet from Server
};

#endif // __ENVIRONMENT_H__
