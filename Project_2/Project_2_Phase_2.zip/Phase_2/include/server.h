// ============== ROBOT NAVIGATION ============== //
// 
// File : server.h
// This module monitors the robots and tells them 
// what to do depending on the robots positions
// and thier sensors.
//
// ============================================== //
#ifndef __SERVER_H__
#define __SERVER_H__
#include "defs.h"

/* Server Definitions */
#define CROSSING    1
#define OBSTACLE    2
#define CLEARED     4
#define NUM_NODES   7       // 7 Nodes

class server : public sc_module {
    public:
        // ----- PORTS ----- //
        sc_in_clk clk;
        sc_in  <sc_bv<3> > packet_fromR[ROBOT_NUM];     // Packet from Robot("Environment")
        sc_out <sc_bv<3> > packet_toR[ROBOT_NUM];       // Packet to Robot ("Environment")    

        // ----- CONSTRUCTOR ----- //
        SC_HAS_PROCESS(server);
            server(sc_module_name name, std::vector<std::list<uint> > robotPath, const std::vector<sc_time> robot_S_T) : 
            sc_module(name),
            _robotPath(robotPath), 
            _robot_S_T(robot_S_T) {

                SC_THREAD(server_rx);
                    for(uint i =  0; i < ROBOT_NUM; ++i) {
                        sensitive << packet_fromR[i];
                    }

                SC_CTHREAD(server_update, clk.pos());

                SC_THREAD(server_tx);
                    sensitive << _s_tx;
                
                /* Output Port Initialization */
                for(uint i =  0; i < ROBOT_NUM; ++i) {
                    packet_toR[i].initialize(0);
                }

                /* RSDS (Robot Status Data Structure) Table Initialization */
                for(unsigned i = 0; i < ROBOT_NUM; ++i) {
                    RSDS[i] = { 0, IDLE, _robotPath[i] };
                    _robotPath[i].pop_front();
                    RSDS[i].NG = _robotPath[i];
                }
                RSDS[0].NN.assign( {0, 2, 1, 4} );
                RSDS[1].NN.assign( {0, 2, 3} );
                RSDS[2].NN.assign( {4, 1, 2, 3, 5, 6} );
                RSDS[3].NN.assign( {6, 5, 4} );
            }
    private:
        // ----- METHODS ----- //
        void server_rx(); 
        void update_robot(sc_bv<3>, uint);
        void server_update();
        void server_tx();

        // ----- INTERNAL VARIABLES ----- //
        /* Robot Path */
        std::vector<std::list<uint> > _robotPath;
        
        /* Robot Start Times */
        const std::vector<sc_time> _robot_S_T;

        /* 
            Contains Robot Node ordering 
        */
        std::vector<struct NO> nodes = {
        /* Node 0 */    {1, 2, 0, 0, 18},
        /* Node 1 */    {3, 1, 0, 0, 26},
        /* Node 2 */    {3, 1, 2, 0, 31},
        /* Node 3 */    {3, 2, 0, 0, 32},
        /* Node 4 */    {3, 4, 0, 0, 39},
        /* Node 5 */    {4, 3, 0, 0, 45},
        /* Node 6 */    {4, 3, 0, 0, 48}
        };   
        
        sc_event _s_tx;                             // Triggered when packet is ready to be Transmitted to Robot
        sc_bv<3> _packet_toR[ROBOT_NUM] = { 0 };    // Holds the current outgoing packets to the robots
        sc_bv<3> _packet_fromR[ROBOT_NUM] = { 0 };  // Holds incoming packets from robots
        sc_time _t;                                 // Holds the current time 
};

#endif // __SERVER_H__
