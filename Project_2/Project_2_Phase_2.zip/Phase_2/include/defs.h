/* Robot Navigation - General Definitions */
#ifndef __DEFS_H__
#define __DEFS_H__
#include "systemc.h"
#include <list>

/* Shared Robot Definitions */
#define ROBOT_NUM           4       // 4 Robots
#define ROBOT_STEP_SIZE     0.5     // 0.5m step size
#define ROBOT_SPEED_MAX     2       // Max speed of robot is 2m/s

/* Shared Server definitions */


/* Server Packet Bit Definitions */
#define _s_bit_CONTINUE     0
#define _s_bit_START        1
#define _s_bit_STOP         2

/* Environment Packet Bit Defnitions */
#define _e_r_bit_CROSSING   0
#define _e_r_bit_OBSTACLE   1
#define _e_r_bit_RESTART    2

/* Shared Robot Navigation Status definitions */
#define STOPPED             "STOPPED"
#define IDLE                "IDLE"
#define MOVING              "MOVING"

/* Shared Obstacle Definitions */
#define OBSTACLE_SPEED_MAX  5       // 5 m/s obstacle speed - humans running
#define OBSTACLE_NUM        6       // 6 Obstacles

/* Shared Grid definitions */
#define GRID_SIZE_X_Y       2       // 2 x 2 meters
#define MAX_GRID_NUM_X      9       // 9 rows
#define MAX_GRID_NUM_Y      10      // 10 columns

/* Holds a grid coordinate */
struct coord {
    float x;
    float y;
};

/* 
    Holds the Lower Left and Upper Right 
    coordinates (x, y) of the Grid 
*/
struct gridcoord{
    struct coord LL;      // Lower Left grid coordinate (x, y)
    struct coord UR;      // Upper Right grid coordinate (x, y)
    uint gridNum;         // Grid Number
    uint N;               // North Grid
    uint S;               // South Grid
    uint W;               // East Grid  
    uint E;               // West Grid
};

/* Define and Initialize Map */
extern struct gridcoord map[MAX_GRID_NUM_X][MAX_GRID_NUM_Y];

/* The RSDS (Robot Status Data Structure) table holds the status information for all robots */                       
struct RSDS {
    float speed;            // Robot current speed
    std::string NS;         // Robot Navigation Status
    std::list<uint> CG;     // Current Grid
    std::list<uint> NG;     // Next Grid
    std::list<uint> NN;     // Next Node
};

/* Contains all robot status information */
extern struct RSDS RSDS[ROBOT_NUM]; 

/* Node Ordering Data Structures */
struct NO {
    uint first;     // First Robot allowed through the node
    uint second;    // Second Robot allowed through the node
    uint third;     // Third Robot allowed through the node
    uint fourth;    // Fourth Robot allowed through the node
    uint gridNum;   // Grid number the node is on
};

#endif // __DEFS_H__
