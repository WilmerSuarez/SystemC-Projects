// ============== ROBOT NAVIGATION ============== //
// 
// File : robot_driver,h
// Drives the inputs going into the robot.
//
// ============================================== //
#ifndef __ROBOT_DRIVER_H__
#define __ROBOT_DRIVER_H__
#include "systemc.h"

SC_MODULE(robot_driver) {
    // ----- PORTS ----- //
    sc_in_clk clk;
    sc_out <sc_bv<3> > driver_packet_fromE{"DRIVER_PACKET_FROME"};        // Packet from Environment
    sc_out <sc_bv<3> > driver_packet_fromS{"DRIVER_PACKET_FROMS"};        // Packet from Server
    
    // ----- MEHODS ----- //
    void robot_driver_proc();

    // ----- CONSTRUCTOR ----- //
    SC_CTOR(robot_driver) {
	    SC_CTHREAD(robot_driver_proc, clk.pos());
    }
};

#endif // __ROBOT_DRIVER_H__
